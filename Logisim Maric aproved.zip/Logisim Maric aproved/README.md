# LogisimMg
Logka
