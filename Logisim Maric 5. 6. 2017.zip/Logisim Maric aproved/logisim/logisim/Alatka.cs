﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Logika_ba
{
    public class Alatka
    {
        static Alatka alatka;
        public static Alatka Al
        {
            get
            {
                return alatka;
            }
            set
            {
                alatka = value;
            }
        }
        public virtual Komponenta NapraviObjekat(int x, int y, int CellSize)
        {
            return alatka.NapraviObjekat(x, y, CellSize);
        }
        public virtual string Text()
        {
            return "Nema nista";
        }
    }
    public class AlatkaI : Alatka
    {
        static AlatkaI alatkai = new AlatkaI();
        public override Komponenta NapraviObjekat(int x, int y, int CellSize)
        {
            CetiriUlaza.Normalizuj(CellSize, ref x, ref y);
            return new I(x, y);
        }
        public static Alatka getAlatka()
        {
            return alatkai;
        }

        public override string Text()
        {
            return "Dodato I";
        }
    }

    public class AlatkaNe : Alatka
    {
        static AlatkaNe alatkaNe = new AlatkaNe();
        public override Komponenta NapraviObjekat(int x, int y, int CellSize)
        {
            CetiriUlaza.Normalizuj(CellSize, ref x, ref y);
            return new Ne(x, y);
        }
        public static Alatka getAlatka()
        {
            return alatkaNe;
        }

        public override string Text()
        {
            return "Dodato Ne";
        }
    }

    public class AlatkaNI : Alatka
    {
        static AlatkaNI alatkani = new AlatkaNI();
        public override Komponenta NapraviObjekat(int x, int y, int CellSize)
        {
            CetiriUlaza.Normalizuj(CellSize, ref x, ref y);
            return new NI(x, y);
        }
        public static Alatka getAlatka()
        {
            return alatkani;
        }

        public override string Text()
        {
            return "Dodato NI";
        }
    }

    public class AlatkaDes : Alatka
    {
        static AlatkaDes alatkaDes = new AlatkaDes();
        public override Komponenta NapraviObjekat(int x, int y, int CellSize)
        {
            Komponenta pom=null;
            CetiriUlaza.Normalizuj(CellSize, ref x, ref y);
            foreach (Komponenta komp in Form1.komponente)
            {
                foreach (var tacka in komp.Oblast())
	            {
		            if(tacka.X==x && tacka.Y==y)
                    {
                        pom = komp;
                        break;
                    }
	            }
            }
            Form1.komponente.Remove(pom);
            return null;
        }
        public static Alatka getAlatka()
        {
            return alatkaDes;
        }

        public override string Text()
        {
            return "Izbacena komponenta";
        }
    }

    /*public class AlatkaZica : Alatka
    {
        static AlatkaZica alatkazica = new AlatkaZica();
        public override Komponenta NapraviObjekat(int x, int y, int CellSize)
        {
            CetiriUlaza.Normalizuj(CellSize, ref x, ref y);
            return new I(x, y);
        }
        public static Alatka getAlatka()
        {
            return alatkazica;
        }

        public override string Text()
        {
            return "Dodata Zica";
        }
    }*/

    public class AlatkaZica : Alatka
    {
        static AlatkaZica alatkazica = new AlatkaZica();

        public override Komponenta NapraviObjekat(int x, int y, int CellSize)
        {
            x += CellSize / 2; y += CellSize / 2;
            x = x - x % CellSize + (x % CellSize) / (CellSize / 2) * CellSize - (CellSize / 2);
            y = y - y % CellSize + (y % CellSize) / (CellSize / 2) * CellSize - (CellSize / 2);
            return new Zica(x, y);
        }
        public static Alatka getAlatka()
        {
            return alatkazica;
        }
        public override string Text()
        {
            return "Dodat Cvor";
        }
    }

    public class AlatkaIli : Alatka
    {
        static AlatkaIli alatkaili = new AlatkaIli();

        public override Komponenta NapraviObjekat(int x, int y, int CellSize)
        {
            CetiriUlaza.Normalizuj(CellSize, ref x, ref y);
            return new Ili(x, y);
        }
        public static Alatka getAlatka()
        {
            return alatkaili;
        }
        public override string Text()
        {
            return "Dodato Ili";
        }
    }

    public class AlatkaLampica : Alatka
    {
        static AlatkaLampica alatkalampica = new AlatkaLampica();

        public override Komponenta NapraviObjekat(int x, int y, int CellSize)
        {
            x += CellSize/2; y += CellSize/2;
            x = x - x % CellSize + (x % CellSize) / (CellSize / 2) * CellSize - (CellSize / 2);
            y = y - y % CellSize + (y % CellSize) / (CellSize / 2) * CellSize - (CellSize / 2);
            return new Lampica(x, y);
        }
        public static Alatka getAlatka()
        {
            return alatkalampica;
        }
        public override string Text()
        {
            return "Dodata Tacka()";
        }
    }
}