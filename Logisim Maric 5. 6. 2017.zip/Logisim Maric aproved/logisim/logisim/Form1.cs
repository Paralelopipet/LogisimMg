﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Logika_ba
{
    public partial class Form1 : Form
    {
        
        int cellSize = 20;
        
        static public List<Komponenta> komponente = new List<Komponenta>();
        
        public Form1()
        {
            InitializeComponent();
        }
        public bool Preklapa(Komponenta trenutna, List<Tacka> lista1)
        {
            List<Tacka> lista2;
            foreach (var komponenta in komponente)
            {
                if (komponenta != trenutna)
                {
                    lista2 = komponenta.Oblast();
                    foreach (var tacka1 in lista1)
                    {
                        foreach (var tacka2 in lista2)
                        {
                            if (tacka1.X == tacka2.X && tacka1.Y == tacka2.Y)
                            {
                                return true;
                            }
                        }
                    }
                }
                
            }
            return false;
            
        }
        public void Refreshh()
        {
            pictureBox1.Refresh();
            
        }

        Ili k;
        private void Form1_Load(object sender, EventArgs e)
        {
            InitializeTreeView();
            Komponenta lampica = new Lampica(10, 10);
            k = new Ili(60, 60);
            k.Dodaj(lampica, 1);
            Tacka.napuni_matricu(pictureBox1.Height, pictureBox1.Width, cellSize);
        }
        private void pictureBox1_Paint(object sender, PaintEventArgs e)
        {
            Graphics g = e.Graphics;
            Pen p = new Pen(Color.Silver);
            for (int x = 0; x < pictureBox1.Width; x+=cellSize)
            {
                for (int y = 0; y < pictureBox1.Height; y += cellSize)
                {
                    g.DrawEllipse(p, x+cellSize/2, y+cellSize/2, 1, 1);
                }
            }
            foreach (var k in komponente)
            {
                if (k!=null) k.Nacrtaj(g);
            }
            //k.Nacrtaj(g);
        }
        Ili ili;
        I i;
        Lampica lampica;



        private void pictureBox1_MouseUp(object sender, MouseEventArgs e)
        {
            if (Trenutna_komponenta.Tren == null)
            {
                if (Alatka.Al != null)
                {
                    if (Alatka.Al.NapraviObjekat(e.X,e.Y,cellSize)!=null)
                    {
                        komponente.Add(Alatka.Al.NapraviObjekat(e.X, e.Y, cellSize));
                        listBox1.Items.Add(Alatka.Al.Text());
                    }
                    
                }
            }
            else 
            {
                if (Alatka.Al.NapraviObjekat(e.X, e.Y, cellSize) == null)
                {
                    listBox1.Items.Add(Alatka.Al.Text());
                }
                else if (!Preklapa(Trenutna_komponenta.Tren,Trenutna_komponenta.Oblast(e.X,e.Y)))
                {
                    Trenutna_komponenta.Tren.Promeni_Poziciju(e.X, e.Y, Trenutna_komponenta.Pomx, Trenutna_komponenta.Pomy);
                    pictureBox1.Refresh();
                    
                }
                Trenutna_komponenta.Tren = null;
            }
            Refreshh();
        }

        private void pictureBox1_MouseDown(object sender, MouseEventArgs e)
        {
            Trenutna_komponenta.dodavanje = true;
            foreach (Komponenta k in komponente)
            {
                if (k.Is_Clicked(e.X,e.Y,cellSize) == true)
                {
                    Trenutna_komponenta.dodavanje = false;
                    Trenutna_komponenta.Tren = k;
                    Trenutna_komponenta.Pomx = e.X;
                    Trenutna_komponenta.Pomy = e.Y;
                }
            }
            /*if(Trenutna_komponenta.dodavanje = true&&typeof(Alatka.Al)==AlatkaZica)
            {
                komponente.Add(Alatka.Al.NapraviObjekat(e.X, e.Y, cellSize));
                listBox1.Items.Add(Alatka.Al.Text());
            }*/
        }

        private void pictureBox1_MouseMove(object sender, MouseEventArgs e)
        {
            if (Trenutna_komponenta.Tren != null)
            {
                int x = Trenutna_komponenta.Tren.X;
                int y = Trenutna_komponenta.Tren.Y;
                Trenutna_komponenta.Tren.Privremena_Pozicija(e.X, e.Y, Trenutna_komponenta.Pomx, Trenutna_komponenta.Pomy);
                pictureBox1.Refresh();
                Trenutna_komponenta.Tren.X=x;
                Trenutna_komponenta.Tren.Y=y;
                
                
            }

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void InitializeTreeView()
        {
            treeView1.BeginUpdate();
            treeView1.Nodes.Add("Kola");
            treeView1.Nodes.Add("Zica");
            treeView1.Nodes.Add("Destruktor");
            treeView1.Nodes[0].Nodes.Add("Pokazivaci");
            treeView1.Nodes[0].Nodes.Add("Kola");
            treeView1.Nodes[0].Nodes[0].Nodes.Add("LED");
            treeView1.Nodes[0].Nodes[1].Nodes.Add("I");
            treeView1.Nodes[0].Nodes[1].Nodes.Add("Ili");
            treeView1.Nodes[0].Nodes[1].Nodes.Add("Ne");
            treeView1.Nodes[0].Nodes[1].Nodes.Add("NI");
            //treeView1.Nodes[0].Nodes[1].Nodes[0]
            treeView1.EndUpdate();
        }

        private void treeView1_AfterSelect(object sender, TreeViewEventArgs e)
        {
            if(treeView1.SelectedNode.Text=="LED")
            {
                Alatka.Al = AlatkaLampica.getAlatka();
                label1.Text = "Lampica alatka";
            }

            if (treeView1.SelectedNode.Text == "Ili")
            {
                Alatka.Al = AlatkaIli.getAlatka();
                label1.Text = "Ili alatka";
            }

            if (treeView1.SelectedNode.Text == "I")
            {
                Alatka.Al = AlatkaI.getAlatka();
                label1.Text = "I alatka";
            }
            if (treeView1.SelectedNode.Text == "Ne")
            {
                Alatka.Al = AlatkaNe.getAlatka();
                label1.Text = "Ne alatka";
            }
            if (treeView1.SelectedNode.Text == "NI")
            {
                Alatka.Al = AlatkaNI.getAlatka();
                label1.Text = "NI alatka";
            }

            if (treeView1.SelectedNode.Text == "Zica")
            {
                Alatka.Al = AlatkaZica.getAlatka();
                label1.Text = "Zica alatka";
            }
            if (treeView1.SelectedNode.Text == "Destruktor")
            {
                Alatka.Al = AlatkaDes.getAlatka();
                label1.Text = "Destruktor";
            }


        }


        /* MOOOORAAAAAAAAAMMMMMMMMMMMMM*/














    }
}