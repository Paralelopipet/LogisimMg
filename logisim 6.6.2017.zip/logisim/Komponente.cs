﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;
namespace Logika_ba
{
    //komponenta crni = new komponenta(10, 2.5, black);
    public abstract class Komponenta
    {
        protected int x, y;
        protected Tacka t;
        public Komponenta(int x, int y)
        {
            this.x = x;
            this.y = y;
        }
        public static int CellSize
        {
            get
            {
                return Form1.CellSize;
            }
        }
        public abstract List<Tacka> Oblast();
        public int X
        {
            get { return this.x; }
            set { x = value; }
        }
        public int Y
        {
            get { return this.y; }
            set { y = value; }
        }
        public abstract bool Vrednost
        {
            get;

        }
        public abstract void Nacrtaj(Graphics g);
        public abstract bool Is_Clicked(int clickedx, int clickedy, int CellSize);
        public abstract void Promeni_Poziciju(int clickedx, int clickedy, int pomx, int pomy);
        public abstract void Privremena_Pozicija(int clickedx, int clickedy, int pomx, int pomy);
        public static void Normalizuj(int CellSize, ref int x, ref int y)
        {
            x += CellSize / 2; y += CellSize / 2;
            x = x - x % CellSize + (x % CellSize) / (CellSize / 2) * CellSize - (CellSize / 2);
            y = y - y % CellSize + (y % CellSize) / (CellSize / 2) * CellSize - (CellSize / 2);
        }

    }
    public class Izvor : Komponenta
    {
        Color c = Color.Red;
        public Izvor(int x, int y)
            : base(x, y)
        {
            this.vrednost = false;
        }
        bool? vrednost=false;
        public void PromeniVrednost()
        {
            if ((bool)vrednost)
            {
                vrednost = false;
                c = Color.Red;
            }
            else
            {
                vrednost = true;
                c = Color.Green;
            }
        }
        public override bool Vrednost
        {
            get
            {
                return (bool)vrednost;
            }
        }
        public override List<Tacka> Oblast()
        {
            List<Tacka> tacke = new List<Tacka>();
            tacke.Add(new Tacka(this.x,this.y));
            return tacke;
        }
        
        public override void Nacrtaj(Graphics g)
        {
            Pen cetka=new Pen(Color.Black);
            g.FillEllipse(new SolidBrush(c), X - CellSize/4, Y - CellSize/4, CellSize/2, CellSize/2);
            g.DrawLine(cetka, new Point(X - CellSize / 4, Y - CellSize/4), new Point(X - CellSize/4, Y + CellSize/4));
            g.DrawLine(cetka, new Point(X - CellSize / 4, Y - CellSize / 4), new Point(X + CellSize / 4, Y - CellSize / 4));
            g.DrawLine(cetka, new Point(X + CellSize / 4, Y + CellSize / 4), new Point(X - CellSize / 4, Y + CellSize / 4));
            g.DrawLine(cetka, new Point(X + CellSize / 4, Y + CellSize / 4), new Point(X + CellSize / 4, Y - CellSize / 4));
        }
        
        public override bool Is_Clicked(int clickedx, int clickedy, int CellSize)
        {
            Izvor.Normalizuj(CellSize, ref clickedx, ref clickedy);
            if ((clickedx == this.x) && (clickedy == this.y)) return true;
            else return false;
        }
        public override void Promeni_Poziciju(int clickedx, int clickedy, int pomx, int pomy)
        {
            Izvor.Normalizuj(CellSize, ref clickedx, ref clickedy);
            if (this.x == clickedx && this.y == clickedy) this.PromeniVrednost();
            this.x = clickedx;
            this.y = clickedy;
        }
        public override void Privremena_Pozicija(int clickedx, int clickedy, int pomx, int pomy)
        {
            Izvor.Normalizuj(CellSize, ref clickedx, ref clickedy);
            this.x = clickedx;
            this.y = clickedy;
        }
    }

    public class Lampica : Komponenta
    {
        Color c = Color.Red;
        public Lampica(int x, int y)
            : base(x, y)
        {
            this.vrednost = false;
        }
        bool? vrednost = false;
        public void PostaviVrednost(Zica zica)
        {
            vrednost = zica.Vrednost;
            if ((bool)vrednost)
                c = Color.Green;
            else
            {
                c = Color.Red;

            }
        }
        public override bool Vrednost
        {
            get
            {
                return (bool)vrednost;
            }
        }
        public override List<Tacka> Oblast()
        {
            List<Tacka> tacke = new List<Tacka>();
            tacke.Add(new Tacka(this.x, this.y));
            return tacke;
        }

        public override void Nacrtaj(Graphics g)
        {
            g.FillEllipse(new SolidBrush(c), x - CellSize / 4, y - CellSize / 4, CellSize / 2, CellSize / 2);
        }
        
        public override bool Is_Clicked(int clickedx, int clickedy, int CellSize)
        {
            Izvor.Normalizuj(CellSize, ref clickedx, ref clickedy);
            if ((clickedx == this.x) && (clickedy == this.y)) return true;
            else return false;
        }
        public override void Promeni_Poziciju(int clickedx, int clickedy, int pomx, int pomy)
        {
            Izvor.Normalizuj(CellSize, ref clickedx, ref clickedy);
            this.x = clickedx;
            this.y = clickedy;
        }
        public override void Privremena_Pozicija(int clickedx, int clickedy, int pomx, int pomy)
        {
            Promeni_Poziciju(clickedx, clickedy, pomx, pomy);
        }
    }

    public abstract class CetiriUlaza : Komponenta
    {
        protected Komponenta[] b = new Komponenta[4];
        public CetiriUlaza(int x, int y)
            : base(x, y)
        {

        }
        public void Dodaj(Komponenta k, int n)
        {
            this.b[n] = k;
        }
         public override List<Tacka> Oblast()
        {
            List<Tacka> tacke = new List<Tacka>();
            //(clickx > x - CellSize && clickx < x + 4 * CellSize && clicky < y + 2 * CellSize && clicky > y - 2 * CellSize)
            for (int i = -1; i <=3; i++)
                for (int j = -2; j <= 2; j++)
                {
                    tacke.Add(new Tacka(this.x+CellSize*i, this.y+CellSize*j));
                }
            return tacke;
        }
        public override bool Is_Clicked(int clickx, int clicky, int CellSize)
        {
            if (clickx > x - CellSize && clickx < x + 4 * CellSize && clicky < y + 2 * CellSize && clicky > y - 2 * CellSize)
            {
                return true;
            }
            return false;
        }
        
        public override void Promeni_Poziciju(int clickedx, int clickedy,int pomx, int pomy)
        {
            clickedx -= pomx;
            clickedy -= pomy;
            CetiriUlaza.Normalizuj(CellSize, ref clickedx, ref clickedy);
            this.x = clickedx;
            this.y = clickedy;
        }
        public override void Privremena_Pozicija(int clickedx, int clickedy, int pomx, int pomy)
        {
            Promeni_Poziciju(clickedx, clickedy, pomx, pomy);
        }
    }

    public class I : CetiriUlaza
    {
        public I(int x, int y)
            : base(x, y) { }
        public override bool Vrednost
        {
            get
            {
                bool? vrednost = null;
                foreach (Komponenta item in b)
                {
                    if (item != null)
                    {
                        if (vrednost == null)
                            vrednost = item.Vrednost;
                        else
                        {
                            if ((bool)vrednost && item.Vrednost)
                            {
                                vrednost = true;
                            }
                            else
                                vrednost = false;
                        }
                    }
                }
                if (vrednost == null)
                    return false;
                else
                    return (bool)vrednost;
            }
        }
        public override void Nacrtaj(Graphics g)
        {
            Pen cetka = new Pen(Color.Black);
            g.DrawPie(cetka, x-3*CellSize/2, y - 2*CellSize, 4*CellSize, 4*CellSize, -90, 180);
            g.DrawRectangle(cetka, x-CellSize/2, y - 2*CellSize, CellSize, 4*CellSize);
            g.DrawLine(cetka, new Point(x-CellSize/2, y - 2 * CellSize), new Point(x - CellSize, y - 2 * CellSize));
            g.DrawLine(cetka, new Point(x-CellSize / 2, y - CellSize), new Point(x - CellSize, y - CellSize));
            g.DrawLine(cetka, new Point(x - CellSize / 2, y + CellSize), new Point(x - CellSize, y + CellSize));
            g.DrawLine(cetka, new Point(x - CellSize / 2, y + 2 * CellSize), new Point(x - CellSize, y + 2 * CellSize));
            g.DrawLine(cetka, new Point(x + 5*CellSize / 2, y), new Point(x + 6*CellSize/2, y));
            g.DrawLine(new Pen(Color.White), new Point(x + CellSize / 2, y - 2 * CellSize), new Point(x + CellSize / 2, y + 2 * CellSize));
        }
    }

    public class Ili : CetiriUlaza
    {
        public Ili(int x, int y)
            : base(x, y)
        {

        }
        public override bool Vrednost
        {
            get
            {
                bool? vrednost = null;
                foreach (Komponenta item in b)
                {
                    if (item != null)
                    {
                        if (vrednost == null)
                            vrednost = item.Vrednost;
                        else
                        {
                            if ((bool)vrednost || item.Vrednost)
                            {
                                vrednost = true;
                            }
                            else
                                vrednost = false;
                        }
                    }
                }
                if (vrednost == null)
                    return false;
                else
                    return (bool)vrednost;


            }
        }
        public override void Nacrtaj(Graphics g)
        {
            Pen cetka = new Pen(Color.Black);
            g.DrawLine(cetka, new Point(x - CellSize / 2, y - 2 * CellSize), new Point(x - CellSize / 2, y + 2 * CellSize));
            g.DrawLine(cetka, new Point(x - CellSize / 2, y - 2 * CellSize), new Point(x + 5 * CellSize / 2, y));
            g.DrawLine(cetka, new Point(x - CellSize / 2, y + 2 * CellSize), new Point(x + 5 * CellSize / 2, y));
            g.DrawLine(cetka, new Point(x - CellSize / 2, y - 2 * CellSize), new Point(x - CellSize, y - 2 * CellSize));
            g.DrawLine(cetka, new Point(x - CellSize / 2, y - CellSize), new Point(x - CellSize, y - CellSize));
            g.DrawLine(cetka, new Point(x - CellSize / 2, y + CellSize), new Point(x - CellSize, y + CellSize));
            g.DrawLine(cetka, new Point(x - CellSize / 2, y + 2 * CellSize), new Point(x - CellSize, y + 2 * CellSize));
            g.DrawLine(cetka, new Point(x + 5 * CellSize / 2, y), new Point(x + 6 * CellSize / 2, y));
           
        }
    }

    public class NIli : CetiriUlaza
    {
        public NIli(int x, int y)
            : base(x, y)
        {

        }
        public override bool Vrednost
        {
            get
            {
                bool? vrednost = null;
                foreach (Komponenta item in b)
                {
                    if (item != null)
                    {
                        if (vrednost == null)
                            vrednost = item.Vrednost;
                        else
                        {
                            if ((bool)vrednost || item.Vrednost)
                            {
                                vrednost = true;
                            }
                            else
                                vrednost = false;
                        }
                    }
                }
                if (vrednost == null)
                    return false;
                else
                    return !(bool)vrednost;


            }
        }
        public override void Nacrtaj(Graphics g)
        {
            Pen cetka = new Pen(Color.Black);
            g.DrawLine(cetka, new Point(x - CellSize / 2, y - 2 * CellSize), new Point(x - CellSize / 2, y + 2 * CellSize));
            g.DrawLine(cetka, new Point(x - CellSize / 2, y - 2 * CellSize), new Point(x + 5 * CellSize / 2, y));
            g.DrawLine(cetka, new Point(x - CellSize / 2, y + 2 * CellSize), new Point(x + 5 * CellSize / 2, y));
            g.DrawLine(cetka, new Point(x - CellSize / 2, y - 2 * CellSize), new Point(x - CellSize, y - 2 * CellSize));
            g.DrawLine(cetka, new Point(x - CellSize / 2, y - CellSize), new Point(x - CellSize, y - CellSize));
            g.DrawLine(cetka, new Point(x - CellSize / 2, y + CellSize), new Point(x - CellSize, y + CellSize));
            g.DrawLine(cetka, new Point(x - CellSize / 2, y + 2 * CellSize), new Point(x - CellSize, y + 2 * CellSize));
            g.DrawLine(cetka, new Point(x + 5 * CellSize / 2 + CellSize / 3, y), new Point(x + 6 * CellSize / 2, y));
            g.DrawEllipse(cetka, x + 5 * CellSize / 2, y - CellSize / 6, CellSize / 3, CellSize / 3);

        }
    }

    public class NI : CetiriUlaza
    {
        public NI(int x, int y)
            : base(x, y) { }
        public override bool Vrednost
        {
            get
            {
                bool? vrednost = null;
                foreach (Komponenta item in b)
                {
                    if (item != null)
                    {
                        if (vrednost == null)
                            vrednost = item.Vrednost;
                        else
                        {
                            if ((bool)vrednost && item.Vrednost)
                            {
                                vrednost = true;
                            }
                            else
                                vrednost = false;
                        }
                    }
                }
                if (vrednost == null)
                    return false;
                else
                    return !(bool)vrednost;
            }
        }
        public override void Nacrtaj(Graphics g)
        {
            Pen cetka = new Pen(Color.Black);
            g.DrawPie(cetka, x - 3 * CellSize / 2, y - 2 * CellSize, 4 * CellSize, 4 * CellSize, -90, 180);
            g.DrawRectangle(cetka, x - CellSize / 2, y - 2 * CellSize, CellSize, 4 * CellSize);
            g.DrawLine(cetka, new Point(x - CellSize / 2, y - 2 * CellSize), new Point(x - CellSize, y - 2 * CellSize));
            g.DrawLine(cetka, new Point(x - CellSize / 2, y - CellSize), new Point(x - CellSize, y - CellSize));
            g.DrawLine(cetka, new Point(x - CellSize / 2, y + CellSize), new Point(x - CellSize, y + CellSize));
            g.DrawLine(cetka, new Point(x - CellSize / 2, y + 2 * CellSize), new Point(x - CellSize, y + 2 * CellSize));
            g.DrawLine(cetka, new Point(x + 5 * CellSize / 2+CellSize/3, y), new Point(x + 6 * CellSize / 2, y));
            g.DrawEllipse(cetka, x + 5 * CellSize / 2, y-CellSize/6, CellSize/3,CellSize/3);
            g.DrawLine(new Pen(Color.White), new Point(x + CellSize / 2, y - 2 * CellSize), new Point(x + CellSize / 2, y + 2 * CellSize));
        }
    }


    public class Ne : Komponenta
    {
        Komponenta k;
        public Ne(int x, int y)
            : base(x, y)
        {

        }
        public override List<Tacka> Oblast()
        {
            List<Tacka> tacke = new List<Tacka>();
            tacke.Add(new Tacka(this.x, this.y));
            tacke.Add(new Tacka(this.x - CellSize, this.y));
            tacke.Add(new Tacka(this.x + CellSize, this.y));
            return tacke;
        }
        public override bool Vrednost
        {
            get
            {
                return !k.Vrednost;

            }
        }
        
        public void Dodaj(Komponenta k)
        {
            this.k = k;
        }
        public override void Nacrtaj(Graphics g)
        {
            Pen cetka = new Pen(Color.Black);
            
            g.DrawLine(cetka, new Point(x +CellSize / 3, y), new Point(x + CellSize, y));
            g.DrawLine(cetka, new Point(x - CellSize, y), new Point(x -CellSize/2, y));
            g.DrawLine(cetka, new Point(x - CellSize/2, y+CellSize/3), new Point(x, y));
            g.DrawLine(cetka, new Point(x - CellSize/2, y-CellSize/3), new Point(x, y));
            g.DrawLine(cetka, new Point(x - CellSize / 2, y - CellSize / 3), new Point(x - CellSize / 2, y + CellSize / 3));
            g.DrawEllipse(cetka, x, y-CellSize/6, CellSize / 3, CellSize / 3);
           
        }
        public override bool Is_Clicked(int clickx, int clicky, int CellSize)
        {
            if (clickx >= x - CellSize && clickx <= x + CellSize && clicky > y-CellSize/2 && clicky <y+CellSize/2)
            {
                return true;
            }
            return false;
        }
        public override void Promeni_Poziciju(int clickedx, int clickedy, int pomx, int pomy)
        {
            clickedx -= pomx;
            clickedy -= pomy;
            CetiriUlaza.Normalizuj(CellSize, ref clickedx, ref clickedy);
            this.x = clickedx;
            this.y = clickedy;
        }
        public override void Privremena_Pozicija(int clickedx, int clickedy, int pomx, int pomy)
        {
            Promeni_Poziciju(clickedx, clickedy, pomx, pomy);
        }
    }

    public class Zica : Komponenta
    {
        Color c = Color.Blue;
        public Zica(int x, int y)
            : base(x, y)
        {
            this.vrednost = false;
        }
        bool? vrednost;
        public void PromeniVrednost()
        {
            if ((bool)vrednost)
                vrednost = false;
            else
                vrednost = true;
        }
        public override bool Vrednost
        {
            get
            {
                return (bool)vrednost;
            }
        }
        public override List<Tacka> Oblast()
        {
            List<Tacka> tacke = new List<Tacka>();
            tacke.Add(new Tacka(this.x, this.y));
            return tacke;
        }
        
        public override void Nacrtaj(Graphics g)
        {
            g.FillEllipse(new SolidBrush(c), x - CellSize / 4, y - CellSize / 4, CellSize / 2, CellSize / 2);
        }
        public void PromeniBoju()
        {
            if (c == Color.Blue)
                c = Color.Green;
            else
                c = Color.Blue;
        }
        public override bool Is_Clicked(int clickedx, int clickedy, int CellSize)
        {
            Izvor.Normalizuj(CellSize, ref clickedx, ref clickedy);
            if ((clickedx == this.x) && (clickedy == this.y))  return true; 
            else return false;
        }
        public override void Promeni_Poziciju(int clickedx, int clickedy, int pomx, int pomy)
        {
            Izvor.Normalizuj(CellSize, ref clickedx, ref clickedy);
            this.x = clickedx;
            this.y = clickedy;
        }
        public override void Privremena_Pozicija(int clickedx, int clickedy, int pomx, int pomy)
        {
            Promeni_Poziciju(clickedx, clickedy, pomx, pomy);
        }
    }
}